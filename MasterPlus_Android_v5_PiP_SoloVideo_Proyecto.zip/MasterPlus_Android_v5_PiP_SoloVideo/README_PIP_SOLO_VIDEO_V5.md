# MasterPlus Android v5 - PiP solo video

Corrección:
- Al pulsar Inicio, la ventana PiP muestra únicamente el video.
- Se ocultan botones, categorías, lista de canales y navegación inferior.
- Al volver a la aplicación, la página recupera su diseño normal.

Versión: 1.2.1
versionCode: 5
Paquete: com.teletop.masterplus
