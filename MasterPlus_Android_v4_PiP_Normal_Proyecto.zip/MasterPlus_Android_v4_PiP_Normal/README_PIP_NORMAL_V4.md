# MasterPlus Android v4 - PiP desde reproductor normal

Ahora Picture-in-Picture funciona sin entrar a pantalla completa:

1. Reproduce un canal en el reproductor normal.
2. Espera uno o dos segundos.
3. Pulsa el botón Inicio del teléfono.
4. El video debe quedar flotando.

La app detecta los eventos play, playing, pause y ended del elemento de video.
No activa PiP cuando no hay un video reproduciéndose.

Versión: 1.2.0
versionCode: 4
Paquete: com.teletop.masterplus
