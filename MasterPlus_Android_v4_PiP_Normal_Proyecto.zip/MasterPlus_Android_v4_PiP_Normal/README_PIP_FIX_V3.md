# MasterPlus Android v3 PiP Fix

Corrección:
- El modo Picture-in-Picture ahora se activa inmediatamente al pulsar Inicio.
- Se eliminó la comprobación JavaScript asíncrona que llegaba tarde.
- PiP se activa cuando el reproductor está en pantalla completa.

Uso:
1. Reproduce un canal.
2. Pulsa Pantalla completa.
3. Espera un segundo.
4. Pulsa Inicio.
5. El video debe quedar flotando.

La aplicación conserva el paquete `com.teletop.masterplus`.
