# Cambios rápidos

## Cambiar la URL

En `app/build.gradle`, busca:

`buildConfigField "String", "START_URL", "\"https://teletop.online/Masterplus/\""`

Cambia solamente la dirección entre comillas.

## Cambiar el nombre visible

Edita:

`app/src/main/res/values/strings.xml`

y modifica:

`<string name="app_name">MasterPlus</string>`

## Cambiar el identificador de la app

En `app/build.gradle`, cambia:

- `namespace`
- `applicationId`

También debes mover `MainActivity.java` al paquete nuevo.
