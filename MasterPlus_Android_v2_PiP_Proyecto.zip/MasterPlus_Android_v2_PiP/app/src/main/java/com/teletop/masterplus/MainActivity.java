package com.teletop.masterplus;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.app.PictureInPictureParams;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.MimeTypeMap;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int WEB_PERMISSION_REQUEST = 1002;
    private static final String TRUSTED_HOST = "teletop.online";

    private FrameLayout rootContainer;
    private WebView webView;
    private ProgressBar progressBar;

    private ValueCallback<Uri[]> filePathCallback;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;

    private PermissionRequest pendingPermissionRequest;
    private boolean videoIsFullscreen = false;
    private String[] pendingAndroidPermissions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);

        rootContainer = findViewById(R.id.rootContainer);
        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);

        configureWebView();

        if (savedInstanceState == null) {
            webView.loadUrl(BuildConfig.START_URL);
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccess(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setUserAgentString(
                settings.getUserAgentString() + " MasterPlusAndroid/1.0"
        );

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new MasterPlusWebViewClient());
        webView.setWebChromeClient(new MasterPlusChromeClient());
        webView.setDownloadListener(createDownloadListener());

        webView.setLongClickable(true);
        webView.setHapticFeedbackEnabled(true);
    }

    private DownloadListener createDownloadListener() {
        return (url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setMimeType(mimeType);
                request.addRequestHeader("User-Agent", userAgent);

                String cookie = CookieManager.getInstance().getCookie(url);
                if (cookie != null) {
                    request.addRequestHeader("Cookie", cookie);
                }

                String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
                request.setTitle(fileName);
                request.setDescription("MasterPlus");
                request.setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                );
                request.setDestinationInExternalPublicDir(
                        Environment.DIRECTORY_DOWNLOADS,
                        fileName
                );

                DownloadManager manager =
                        (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                manager.enqueue(request);

                Toast.makeText(
                        MainActivity.this,
                        R.string.download_started,
                        Toast.LENGTH_SHORT
                ).show();
            } catch (Exception error) {
                openExternal(Uri.parse(url));
            }
        };
    }

    private final class MasterPlusWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(
                WebView view,
                WebResourceRequest request
        ) {
            return handleUri(request.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleUri(Uri.parse(url));
        }

        private boolean handleUri(Uri uri) {
            String scheme = uri.getScheme() == null
                    ? ""
                    : uri.getScheme().toLowerCase(Locale.ROOT);

            if ("http".equals(scheme) || "https".equals(scheme)) {
                String host = uri.getHost();

                if (host != null && (
                        host.equals(TRUSTED_HOST)
                        || host.endsWith("." + TRUSTED_HOST)
                )) {
                    return false;
                }

                // Permite que los streams HTTP/HTTPS se carguen dentro del WebView.
                // Los enlaces de navegación externos se abren fuera.
                String path = uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.ROOT);
                if (
                        path.endsWith(".m3u8")
                        || path.endsWith(".mp4")
                        || path.endsWith(".ts")
                ) {
                    return false;
                }

                openExternal(uri);
                return true;
            }

            if (
                    "intent".equals(scheme)
                    || "whatsapp".equals(scheme)
                    || "mailto".equals(scheme)
                    || "tel".equals(scheme)
                    || "market".equals(scheme)
            ) {
                openExternal(uri);
                return true;
            }

            return false;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgress(10);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            progressBar.setProgress(100);
            progressBar.setVisibility(View.GONE);
        }

        @Override
        public void onReceivedError(
                WebView view,
                WebResourceRequest request,
                WebResourceError error
        ) {
            if (request.isForMainFrame()) {
                Toast.makeText(
                        MainActivity.this,
                        R.string.connection_error,
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }

    private final class MasterPlusChromeClient extends WebChromeClient {

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            progressBar.setProgress(newProgress);
            progressBar.setVisibility(
                    newProgress >= 100 ? View.GONE : View.VISIBLE
            );
        }

        @Override
        public boolean onShowFileChooser(
                WebView webView,
                ValueCallback<Uri[]> callback,
                FileChooserParams fileChooserParams
        ) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
            }

            filePathCallback = callback;

            Intent intent;
            try {
                intent = fileChooserParams.createIntent();
            } catch (Exception error) {
                intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
            }

            try {
                startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                return true;
            } catch (ActivityNotFoundException error) {
                filePathCallback = null;
                Toast.makeText(
                        MainActivity.this,
                        R.string.no_app_found,
                        Toast.LENGTH_LONG
                ).show();
                return false;
            }
        }

        @Override
        public void onShowCustomView(
                View view,
                CustomViewCallback callback
        ) {
            if (customView != null) {
                callback.onCustomViewHidden();
                return;
            }

            customView = view;
            customViewCallback = callback;
            videoIsFullscreen = true;

            webView.setVisibility(View.GONE);
            rootContainer.addView(
                    customView,
                    new FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                    )
            );

            enterImmersiveMode();
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) {
                return;
            }

            rootContainer.removeView(customView);
            customView = null;
            videoIsFullscreen = false;

            if (customViewCallback != null) {
                customViewCallback.onCustomViewHidden();
                customViewCallback = null;
            }

            webView.setVisibility(View.VISIBLE);
            exitImmersiveMode();
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            if (!isTrustedOrigin(request.getOrigin())) {
                request.deny();
                return;
            }

            pendingPermissionRequest = request;
            pendingAndroidPermissions = mapWebPermissions(request.getResources());

            if (pendingAndroidPermissions.length == 0) {
                request.grant(request.getResources());
                pendingPermissionRequest = null;
                return;
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(
                        pendingAndroidPermissions,
                        WEB_PERMISSION_REQUEST
                );
            } else {
                request.grant(request.getResources());
                pendingPermissionRequest = null;
            }
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(
                String origin,
                GeolocationPermissions.Callback callback
        ) {
            callback.invoke(origin, false, false);
        }
    }

    private boolean isTrustedOrigin(Uri origin) {
        String host = origin.getHost();
        return host != null && (
                host.equals(TRUSTED_HOST)
                || host.endsWith("." + TRUSTED_HOST)
        );
    }

    private String[] mapWebPermissions(String[] resources) {
        boolean camera = false;
        boolean microphone = false;

        for (String resource : resources) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                camera = true;
            }

            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                microphone = true;
            }
        }

        if (camera && microphone) {
            return new String[]{
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO
            };
        }

        if (camera) {
            return new String[]{Manifest.permission.CAMERA};
        }

        if (microphone) {
            return new String[]{Manifest.permission.RECORD_AUDIO};
        }

        return new String[0];
    }

    private void openExternal(Uri uri) {
        try {
            Intent intent;

            if ("intent".equalsIgnoreCase(uri.getScheme())) {
                intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
            } else {
                intent = new Intent(Intent.ACTION_VIEW, uri);
            }

            startActivity(intent);
        } catch (Exception error) {
            Toast.makeText(
                    this,
                    R.string.no_app_found,
                    Toast.LENGTH_LONG
            ).show();
        }
    }


    private boolean canUsePictureInPicture() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_PICTURE_IN_PICTURE
                );
    }

    private void enterPictureInPictureIfPlaying() {
        if (!canUsePictureInPicture()) {
            return;
        }

        webView.evaluateJavascript(
                "(function(){"
                        + "var v=document.querySelector('video');"
                        + "return !!(v && !v.paused && !v.ended && v.readyState>2);"
                        + "})()",
                result -> {
                    boolean htmlVideoPlaying = "true".equals(result);

                    if (!videoIsFullscreen && !htmlVideoPlaying) {
                        return;
                    }

                    try {
                        PictureInPictureParams params =
                                new PictureInPictureParams.Builder()
                                        .setAspectRatio(new Rational(16, 9))
                                        .build();

                        enterPictureInPictureMode(params);
                    } catch (Exception ignored) {
                    }
                }
        );
    }

    private void enterImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(
                        WindowInsets.Type.statusBars()
                                | WindowInsets.Type.navigationBars()
                );
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                );
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        }
    }

    private void exitImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.show(
                        WindowInsets.Type.statusBars()
                                | WindowInsets.Type.navigationBars()
                );
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_VISIBLE
            );
        }
    }


    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        enterPictureInPictureIfPlaying();
    }

    @Override
    public void onPictureInPictureModeChanged(
            boolean isInPictureInPictureMode,
            android.content.res.Configuration newConfig
    ) {
        super.onPictureInPictureModeChanged(
                isInPictureInPictureMode,
                newConfig
        );

        if (isInPictureInPictureMode) {
            enterImmersiveMode();
        } else {
            exitImmersiveMode();
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            ((MasterPlusChromeClient) webView.getWebChromeClient()).onHideCustomView();
            return;
        }

        if (webView.canGoBack()) {
            webView.goBack();
            return;
        }

        super.onBackPressed();
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) {
            return;
        }

        Uri[] results = WebChromeClient.FileChooserParams.parseResult(
                resultCode,
                data
        );

        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (
                requestCode != WEB_PERMISSION_REQUEST
                || pendingPermissionRequest == null
        ) {
            return;
        }

        boolean granted = true;

        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                granted = false;
                break;
            }
        }

        if (granted) {
            pendingPermissionRequest.grant(
                    pendingPermissionRequest.getResources()
            );
        } else {
            pendingPermissionRequest.deny();
        }

        pendingPermissionRequest = null;
        pendingAndroidPermissions = null;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
        }

        super.onDestroy();
    }
}
