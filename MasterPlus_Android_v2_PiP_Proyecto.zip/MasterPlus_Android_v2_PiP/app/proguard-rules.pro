# MasterPlus utiliza WebView y no requiere reglas especiales por ahora.
