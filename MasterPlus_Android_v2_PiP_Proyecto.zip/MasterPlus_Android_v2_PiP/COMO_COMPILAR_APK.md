# Cómo obtener el APK sin programar

## Opción 1: Android Studio

1. Instala Android Studio.
2. Abre la carpeta `MasterPlus_Android_v1`.
3. Espera a que termine la sincronización.
4. Abre el menú **Build**.
5. Selecciona **Build APK(s)**.
6. El APK quedará en:

   `app/build/outputs/apk/debug/app-debug.apk`

## Opción 2: GitHub, sin instalar Android Studio

1. Crea una cuenta gratuita en GitHub.
2. Crea un repositorio nuevo.
3. Sube todos los archivos de este proyecto.
4. Abre la pestaña **Actions**.
5. Selecciona **Compilar APK MasterPlus**.
6. Pulsa **Run workflow**.
7. Al terminar, descarga el archivo **MasterPlus-APK**.
8. Dentro estará `app-debug.apk`.

El APK de prueba se puede instalar manualmente. Para publicar o actualizar
formalmente la app, debes crear y conservar una clave de firma.
