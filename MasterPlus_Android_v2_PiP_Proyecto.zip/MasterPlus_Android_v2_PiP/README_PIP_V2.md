# MasterPlus Android v2 PiP

Uso:
1. Reproduce un canal.
2. Pulsa Pantalla completa.
3. Pulsa el botón Inicio del teléfono.
4. El video debe quedar flotando en una ventana pequeña.

Requisitos:
- Android 8.0 o superior.
- Picture-in-Picture permitido para MasterPlus en Ajustes del teléfono.

La app conserva el mismo paquete `com.teletop.masterplus`, así que esta versión
puede instalarse encima de la anterior como actualización.
