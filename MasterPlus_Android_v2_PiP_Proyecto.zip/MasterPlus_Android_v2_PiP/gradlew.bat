@echo off
where gradle >nul 2>nul
if %errorlevel%==0 (
  gradle %*
  exit /b %errorlevel%
)
echo Gradle no esta instalado. Abre el proyecto con Android Studio o usa GitHub Actions.
exit /b 1
